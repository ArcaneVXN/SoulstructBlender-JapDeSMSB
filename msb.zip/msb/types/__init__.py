"""No imports into this namespace. Game-specific modules and base/adapter classes must be imported specifically."""
